<footer class="main-footer">
  <div class="float-right d-none d-sm-block">
    <b>Version</b> <?= strtoupper($Page->footer->version) ?>
  </div>
  <strong><a href="https://flyingcolour.net"><?= strtoupper($Page->footer->name) ?></a>.</strong> All rights reserved.
</footer>