<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
//this completly based on user Logout only
class LockController extends BaseController
{
    public function index()
    {
        //
    }
}
